//
//  MyCustomXValueFormatter.h
//  ChartsDemo
//
//  Created by Daniel Cohen Gindi on 21/9/15.
//  Copyright © 2015 dcg. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Charts/Charts.h>

@interface MyCustomXValueFormatter : NSObject <ChartXAxisValueFormatter>

@end

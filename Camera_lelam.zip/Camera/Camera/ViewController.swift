//
//  ViewController.swift
//  Camera
//
//  Created by LeLam on 8/1/15.
//  Copyright (c) 2015 LeLam. All rights reserved.
//

import UIKit
import Parse


extension UIImage {
    var highestQualityJPEGNSData:NSData {
        return UIImageJPEGRepresentation(self, 1.0)
    }
    var highQualityJPEGNSData:NSData    {
        return UIImageJPEGRepresentation(self, 0.75)
    }
    var mediumQualityJPEGNSData:NSData  {
        return UIImageJPEGRepresentation(self, 0.5)
    }
    var lowQualityJPEGNSData:NSData     {
        return UIImageJPEGRepresentation(self, 0.25)
    }
    var lowestQualityJPEGNSData:NSData  {
        return UIImageJPEGRepresentation(self, 0.0)
    }
}

class ViewController: UIViewController,UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    var newMedia: Bool?
    
    @IBOutlet weak var imgHinh: UIImageView!
    var imgUp:UIImage!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var la:UIImage = UIImage()
        
    }
    
    @IBAction func CallCamera(sender: UIButton) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera){
            let imgPick = UIImagePickerController()
            imgPick.delegate = self
            imgPick.sourceType = UIImagePickerControllerSourceType.Camera
            self.presentViewController(imgPick, animated: true, completion: nil)
            newMedia = true
        }
        
    }
    
    func image(image: UIImage, didFinishSavingWithError error: NSErrorPointer, contextInfo:UnsafePointer<Void>) {
        
    }

    @IBAction func loadImage(sender: UIButton) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.PhotoLibrary) {
            let imgPick = UIImagePickerController()
            imgPick.delegate = self
            imgPick.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
            self.presentViewController(imgPick, animated: true, completion: nil)
            newMedia = false
        }
    }

    
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [NSObject : AnyObject]) {
        
        let mediaType = info[UIImagePickerControllerMediaType] as! String
        self.dismissViewControllerAnimated(true, completion: nil)
            var image = info[UIImagePickerControllerOriginalImage] as! UIImage
            imgHinh.image = image
            imgUp = image
            if (newMedia == true) {
                UIImageWriteToSavedPhotosAlbum(image, self,
                    "image:didFinishSavingWithError:contextInfo:", nil)
            }
    }
    
    
    @IBAction func upParse(sender: UIButton) {
        var imageData = UIImagePNGRepresentation(imgUp)
        var chuyenHinh = imgUp.mediumQualityJPEGNSData
        let imageFile = PFFile(name:"image.png", data:chuyenHinh)
        var userPhoto = PFObject(className:"HinhAnh")
        userPhoto["Hinh"] = imageFile
        userPhoto.saveInBackgroundWithBlock({
            (success, error) -> Void in
            if success {
                println("save thanh cong")
            }
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

